<?php 

#librerie
require_once dirname(__FILE__).'/../html2pdf/vendor/autoload.php';
use Spipu\Html2Pdf\Html2Pdf;
use Spipu\Html2Pdf\Exception\Html2PdfException;
use Spipu\Html2Pdf\Exception\ExceptionFormatter;
$testo = $_POST["mytextarea"];

//array (Al posto di una table sql)
$x = array("iva"=>"08613620015","darwin"=>"ciao","alfa"=>"romeo");
$keys = array_keys($x);
$values = array_values($x);



for($i=0;$i<count($keys);$i++)
$testo = str_replace("{".$keys[$i]."}",$values[$i],$testo);

try {
	#ricavo il contenuto della text area
    #$content = $_POST["mytextarea"];
	
	#--------------------------------------
	#PARTE INSERIMENTO DEL DB
	
	
	#--------------------------------------
	
	
	
	
	#--------------------------------------
	#CREAZIONE PDF
	#--------------------------------------
	//contenuto in formato html - Aggiunta header & footer
	$content= "
	<page backtop='40mm' backbottom='40mm' backleft='10mm' backright='10mm'>
		<page_header> 
			<div style='text-align:center'><img src='logo.png' alt='logo'></div>
		</page_header>
	<page_footer>
		<hr>
        <h4>Fondazione Piemonte dal Vivo Circuito Regionale Multidisciplinare</h4>
		<p>Via Bertola, 34 | 10121 Torino - Italy | Tel. +39 011 4320791 | Cod. fisc./P.iva 08613620015
		<br>Mail: info@piemontedalvivo.it | www.piemontedalvivo.it</p>
    </page_footer> 
	
	".$testo.
	"</page>";
	
	//creo il pdf 
    $html2pdf = new Html2Pdf('P','A4','it', false, 'ISO-8859-15', array(20,20,20,20)); 
    $html2pdf->writeHTML($content);
    $html2pdf->output('exemple02.pdf');
	
	
} catch (Html2PdfException $e) {
	#messaggi di errore
    $formatter = new ExceptionFormatter($e);
    echo $formatter->getHtmlMessage();
}
?>