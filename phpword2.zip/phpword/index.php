<?php

#File index.php
#--------------
#Input: Il file docx del contratto
#Output: Un file pdf che espliciti il docx
#PHP si mette in mezzo per caricare i dati su MySQL
#--------------

/*
file necessari 
---------------
PHPWORD
TCPDF
FPDI - FPDF
---------------
*/

require_once ('vendor/autoload.php');
require_once('../tcpdf/tcpdf.php');
require_once('../fpdi/fpdi.php');

//percorsi per TCPDF
\PhpOffice\PhpWord\Settings::setPdfRendererPath('../tcpdf');
\PhpOffice\PhpWord\Settings::setPdfRendererName('TCPDF');

#$phpword = new \PhpOffice\PhpWord\PhpWord();

//percorso del file docx
$fileName = 'C:\xampp29\htdocs\phpword\Ciao.docx';

//carico il file
$phpword = \PhpOffice\PhpWord\IOFactory::load($fileName);


//apro il template
$document = $phpword->loadTemplate('Ciao.docx');
//ricavo le sezioni del file docx
$sections = $phpword->getSections();
$section = $sections[0]; 

$arrays = $section->getElements();
#print_r($arrays);
//ricavo gli header
$headers = $section->getHeaders();
$header1 = $headers[1]; // note that the first index is 1 here (not 0)


$elements = $header1->getElements();
$element1 = $elements[0]; // and first index is 0 here normally

$file = $element1->getText();


//ricavo i footer
$footers = $section->getFooters(); // to access footer

//salvo un file temporaneo copia del file originale
$document->saveAs('temp.docx');
//carico il file temp
$phpword = \PhpOffice\PhpWord\IOFactory::load('temp.docx'); 


// converto in pdf
$xmlWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpword , 'PDF');
$xmlWriter->save('temp.pdf');  



// Creating new page with PDF as a background
$pdf = new FPDI();

$pdf->setSourceFile('temp.pdf');

$tplIdx = $pdf->importPage(1);
$pdf->AddPage();
$pdf->useTemplate($tplIdx, 0, 0, 0, 0, true);



// $pdf->MultiCell(0, 5,'$pdf', 0, 'J', 0, 2, '', '', true, 0, false);
// aggiungo il Logo al pdf esistente
$pdf->Image('apple.jpg', 25, 25, 50, '', '', '', '', false, 50);


// clean the output buffer
ob_clean();

//download del pdf
$pdf->Output($file.'.pdf', 'D');

//elimino il file temp
unlink('temp.docx'); 


?>