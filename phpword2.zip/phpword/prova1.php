<?php




require_once 'vendor/autoload.php';

$fileName = 'C:\xampp29\htdocs\phpword\Ciao.docx';
$phpWord = \PhpOffice\PhpWord\IOFactory::load($fileName);

$sections = $phpWord->getSections();
$section = $sections[0]; 
$arrays = $section->getElements();
print_r($arrays);



?>